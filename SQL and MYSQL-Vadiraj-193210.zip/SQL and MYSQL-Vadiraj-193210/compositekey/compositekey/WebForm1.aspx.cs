﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace compositekey
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }
        protected void lbinsert_Click(object sender, EventArgs e)
        {
            SqlDataSource1.InsertParameters["pslno"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtpslno")).Text;
            SqlDataSource1.InsertParameters["pid"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtpid")).Text;
            SqlDataSource1.InsertParameters["pname"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtpname")).Text;
            SqlDataSource1.InsertParameters["pcity"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtpcity")).Text;

            SqlDataSource1.Insert();
        }
    }
}